package com.example.licenta_patras

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
