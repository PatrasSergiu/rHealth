

// login text field data
import 'model/appUser.dart';

String? inputEmail;
String? inputPassword;

// SignUp text field data
String? inputFullName;
String? inputPhoneNo;
String? inputConfirmPassword;
String? doctorId;
String? inputVarsta;

AppUser? loggedUser;
String? editedUser;

///doctor
String? descriereDoctor;