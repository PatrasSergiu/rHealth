enum UserRole {
  pacient,
  medic,
  admin
}