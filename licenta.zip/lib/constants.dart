import 'package:flutter/material.dart';

const Color primaryColorC = Color(0xff5a9bef);
const Color accentColorC = Color(0xff5a9bef);
const Color textFieldBGColor = Color(0xff5f9ced); // #5f9ced
const Color textColor = Color(0xffddf2f9);
const Color listSlideColor = Color(0xFF23314C);
const Color textColorTransparent = Color(0x66ddf2f9);
